// Harsh Bawankar portfolio interactions
const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const themeButton = document.querySelector(".theme-toggle");
const backToTop = document.querySelector(".back-to-top");

// Mobile navigation
menuButton.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuButton.textContent = isOpen ? "✕" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
    menuButton.textContent = "☰";
  });
});

// Light/dark theme toggle; remembers the choice in this browser
const savedTheme = localStorage.getItem("harsh-portfolio-theme");
if (savedTheme === "light") {
  document.body.classList.add("light-theme");
  themeButton.textContent = "☾";
}

themeButton.addEventListener("click", () => {
  const isLight = document.body.classList.toggle("light-theme");
  themeButton.textContent = isLight ? "☾" : "☼";
  localStorage.setItem("harsh-portfolio-theme", isLight ? "light" : "dark");
  themeButton.setAttribute("aria-label", isLight ? "Switch to dark theme" : "Switch to light theme");
});

// Reveal sections as they enter the viewport
const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealItems.forEach((item) => observer.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add("is-visible"));
}

// Back-to-top button
window.addEventListener("scroll", () => {
  backToTop.classList.toggle("visible", window.scrollY > 500);
}, { passive: true });

backToTop.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// Current year in footer
document.querySelector("#year").textContent = new Date().getFullYear();
