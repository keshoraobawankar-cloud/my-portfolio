# Harsh Bawankar — Personal Portfolio

A responsive, dark-first portfolio built with plain HTML, CSS and JavaScript for a first-year web development recruitment task.

## Run locally
1. Extract the project folder.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Internet is only needed for the optional Google Fonts import; the page otherwise runs locally.

## Features
- Responsive layout and mobile navigation
- Light/dark theme toggle (remembers selection in the browser)
- Scroll reveal animations and back-to-top control
- About, skills, projects, education/journey and contact sections
- Reduced-motion accessibility support
- No frontend frameworks or libraries

## Before presenting
- Check your email and social links.
- Confirm you are comfortable sharing the contact information currently displayed.
- Add project URLs or screenshots only when you have public, working links.
- Update project descriptions if their status changes.
- Be prepared to explain the HTML structure, CSS Grid/Flexbox, media queries, DOM events and IntersectionObserver.

## Files
- `index.html` — page structure and content
- `style.css` — styling, responsive layouts and animations
- `script.js` — navigation, theme toggle, reveal animations and footer year
